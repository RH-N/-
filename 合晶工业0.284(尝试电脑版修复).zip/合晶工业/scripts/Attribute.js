const 地能 =Attribute.add("地能")
exports.地能 =地能