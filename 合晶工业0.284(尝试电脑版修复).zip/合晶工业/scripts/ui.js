//此代码来自创世神
Events.on(EventType.ClientLoadEvent, e => {
    let first = true;
    Vars.ui.settings.game.sliderPref(Core.bundle.format("加速"), 100, 0, 10000, 25, i => {
        if(first){
            first = false;
            return;
        };
        let s = i / 100; Time.setDeltaProvider(() => Math.min(Core.graphics.getDeltaTime() * 60 * s, 3 * s));
        return i + "%";
    });
});