const 特种陆军工厂 = extend(UnitFactory, "特种陆军工厂", {});
exports.特种陆军工厂 = 特种陆军工厂;
特种陆军工厂.category = Category.logic;

const 特种飞机工厂 = extend(UnitFactory, "特种飞机工厂", {});
exports.特种飞机工厂 = 特种飞机工厂;
特种飞机工厂.category = Category.logic;

const 特种海军工厂 = extend(UnitFactory, "特种海军工厂", {});
exports.特种海军工厂 = 特种海军工厂;
特种海军工厂.category = Category.logic;