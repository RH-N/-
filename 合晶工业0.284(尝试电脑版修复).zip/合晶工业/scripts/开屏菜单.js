//以下注释为VSHES荔枝独立完成为了让其他开发者同样可以更新开屏显示窗口插件
Events.on(EventType.ClientLoadEvent, cons(e => {
	var dialog = new BaseDialog("[#5898F0FF]合晶工业");//新建一个显示窗口
	
	dialog.buttons.button("@close", run(() => {
		dialog.hide()//退出此界面
	})).size(128, 64);//按钮用原版@close贴图
		 dialog.cont.button("加入合晶工厂qq群",run(() => {
               Core.app.openURI("http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=Rrju8RLWbsJstJ3rcJxWyrtop4u7uRb9&authKey=gdngZkPeYxZPhYTmjQUTjPos%2FJKckD02YSFnYLmdVojPZIzZw1T%2FbtubSoyuw2LA&noverify=0&group_code=756820891");
             })).size(110,70).pad(3);//添加qq群功能为荔枝VSHES添加
		dialog.cont.pane((() => {
			var table = new Table();
			table.add("感谢游玩本模组，本模组目前（应该吧？）处于早期版本，即将进入中期，所以有许多不足，请多多包涵。本模组贴图目前可能不是太美观，但作者一定会在未来的版本中将这些不足的贴图一一替换，请敬请期待。\n注：模组含有大量蓝色元素，对蓝色过敏者慎入[doge]").left().growX().wrap().width(340).maxWidth(340).pad(4).labelAlign(Align.left);
			table.row();
			return table;
		})()).grow().center().maxWidth(340);
  	dialog.buttons.button("[#FF0000FF]注意事项（一定要看！！！）", run(() => {
		var dialog2 = new BaseDialog("注意事项");
		dialog2.cont.pane((() => {
			var table = new Table();
			table.add('其实啥都没有。\n以此祝福(祭奠)\n我亲爱(赤石)\n的高尚(猥琐)\n的年级主任').left().growX().wrap().width(340).maxWidth(340).pad(4).labelAlign(Align.left);
			table.row();
			return table;
		})()).grow().center().maxWidth(340);
		dialog2.buttons.defaults().size(210, 64);
		dialog2.cont.image(Core.atlas.find("合晶工业-图片1")).row();
		dialog2.addCloseButton();
		dialog2.show();
	})).size(210, 64);
		dialog.buttons.button("[#99F8FFFF]可能的bug", run(() => {
		var dialog3 = new BaseDialog('可能的bug');
		dialog3.cont.pane((() => {
			var table = new Table();
			table.add("1.如果你卫星打输后再打时给的是赛普罗大型核心，那么请先点击保存并退出，打开星球界面，进行重置地图，注意此时一定无核心爆炸动画，否则无效。不要直接从地图打开星球界面重置，这样会有核心爆炸动画。\n\n\n2.若出现挖矿机只挖单一矿物,即使此类矿物已经装满核心但其他矿物未装满的情况,那么请退出并重新进入游戏\n\n\n3.本模组兼容性不高,请不要加除辅助模组之外的模组(部分可以兼容),若出现持续报错,并且你有游玩本模组的决心的话，请保存你的数据,然后删除数据后重新加载本模组\n\n\n如果出现其他未知bug,欢迎来群讨论,群号756820891,届时将会收录你提出的bug").left().growX().wrap().width(340).maxWidth(340).pad(4).labelAlign(Align.left);
			table.row();
			return table;
		})()).grow().center().maxWidth(340);
		dialog3.buttons.defaults().size(210, 64);
		dialog3.addCloseButton();
		dialog3.show();
	})).size(210, 64);
           dialog.show();
}))
