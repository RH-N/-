function newItem(name) {
	exports[name] = extend(Item, name, {});
}
function newCellLiquid(name) {
	exports[name] = extend(CellLiquid, name, {});
}
function newLiquid(name) {
	exports[name] = extend(Liquid, name, {});
}
function newBlock(name) {
	exports[name] = extend(Block, name, {});
}

newItem("铝")
newItem("锂")
newItem("废渣")
newItem("碳单质")
newItem("粗硅晶")
newItem("有机玻璃")
newItem("磷")
newItem("炸药")
newItem("油藻")
newItem("锡")
newItem("金")
newItem("赤金")
newItem("铀")
newItem("铝钢")
newItem("塑胶")
newItem("纯硅晶")
newItem("废晶")
newItem("固态能")
newItem("金辉合金")
newItem("初代合晶")
newItem("次代合晶")
newItem("超代合晶")
newLiquid("能量流体")
