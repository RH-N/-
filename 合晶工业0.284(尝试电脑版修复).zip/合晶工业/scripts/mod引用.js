let mod = Vars.mods.locateMod("multi-crafter");
 if (mod == null) {
	 let bd = Vars.mods.locateMod("合晶工业");
	 let fi = bd.root.child("mod")
		 .child("多合成前置MultiCrafterLib.jar");
	 Vars.mods.importMod(fi);
 };