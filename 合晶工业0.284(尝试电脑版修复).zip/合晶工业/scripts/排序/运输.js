const 铝传送带 = extend(Conveyor, "铝传送带", {});
exports.铝传送带 = 铝传送带;
铝传送带.category = Category.logic;

const 锡传送带 = extend(Conveyor, "锡传送带", {});
exports.锡传送带 = 锡传送带;
锡传送带.category = Category.logic;

const 赤金传送带 = extend(Conveyor, "赤金传送带", {});
exports.赤金传送带 = 赤金传送带;
赤金传送带.category = Category.logic;

const 废晶传送带 = extend(StackConveyor, "废晶传送带", {});
exports.废晶传送带 = 废晶传送带;
废晶传送带.category = Category.logic;

const 塑胶传送带 = extend(StackConveyor, "塑胶传送带", {});
exports.塑胶传送带 = 塑胶传送带;
塑胶传送带.category = Category.logic;

const 压缩传送带 = extend(StackConveyor, "压缩传送带", {});
exports.压缩传送带 = 压缩传送带;
压缩传送带.category = Category.logic;

const 装甲锡传送带 = extend(ArmoredConveyor, "装甲锡传送带", {});
exports.装甲锡传送带 = 装甲锡传送带;
装甲锡传送带.category = Category.logic;

const 装甲赤金传送带 = extend(ArmoredConveyor, "装甲赤金传送带", {});
exports.装甲赤金传送带 = 装甲赤金传送带;
装甲赤金传送带.category = Category.logic;

const 铝连接器 = extend(Junction, "铝连接器", {});
exports.铝连接器 = 铝连接器;
铝连接器.category = Category.logic;

const 铝路由器 = extend(Router, "铝路由器", {});
exports.铝路由器 = 铝路由器;
铝路由器.category = Category.logic;

const 铝分配器 = extend(Router, "铝分配器", {});
exports.铝分配器 = 铝分配器;
铝分配器.category = Category.logic;

const 铝传送带桥 = extend(ItemBridge, "铝传送带桥", {});
exports.铝传送带桥 = 铝传送带桥;
铝传送带桥.category = Category.logic;

const 锡传送带桥 = extend(ItemBridge, "锡传送带桥", {});
exports.锡传送带桥 = 锡传送带桥;
锡传送带桥.category = Category.logic;

const 赤金传送带桥 = extend(ItemBridge, "赤金传送带桥", {});
exports.赤金传送带桥 = 赤金传送带桥;
赤金传送带桥.category = Category.logic;

const 铝分类器 = extend(Sorter, "铝分类器", {});
exports.铝分类器 = 铝分类器;
铝分类器.category = Category.logic;

const 铝反向分类器 = extend(Sorter, "铝反向分类器", {});
exports.铝反向分类器 = 铝反向分类器;
铝反向分类器.category = Category.logic;

const 铝溢流门 = extend(OverflowGate, "铝溢流门", {});
exports.铝溢流门 = 铝溢流门;
铝溢流门.category = Category.logic;

const 铝反向溢流门 = extend(OverflowGate, "铝反向溢流门", {});
exports.铝反向溢流门 = 铝反向溢流门;
铝反向溢流门.category = Category.logic;