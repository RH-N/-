const 基础核心 = extend(CoreBlock, "基础核心", {});
exports.基础核心 = 基础核心;
基础核心.category = Category.logic;



const 晶体核心 = extend(CoreBlock, "晶体核心", {});
exports.晶体核心 = 晶体核心;
晶体核心.category = Category.logic;



const 核心基站 = extend(CoreBlock, "核心基站", {    canBreak() { return Vars.state.teams.cores(Vars.player.team()).size > 1; },
    canReplace(other) { return other.alwaysReplace; },
	canPlaceOn(tile, team) {
		return Vars.state.teams.cores(team).size < 6;
	},
});
exports.核心基站 = 核心基站;
核心基站.category = Category.logic;
/*
const 合晶核心l = extend(CoreBlock, "合晶核心l", {});
exports.合晶核心l = 合晶核心l;
合晶核心l.category = Category.logic
*/
const 合晶核心ll = extend(CoreBlock, "合晶核心ll", {});
exports.合晶核心ll = 合晶核心ll;
合晶核心ll.category = Category.logic;