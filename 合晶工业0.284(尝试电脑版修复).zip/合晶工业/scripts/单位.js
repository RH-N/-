function newUnit(name, unitType) {
	const u = extend(UnitType, name, {});
	u.constructor = () => extend(unitType, {});
	return exports[name] = u;
}

/*"flying" -> UnitEntity;
"mech" -> MechUnit;
"legs" -> LegsUnit;
"naval" -> UnitWaterMove;
"payload" -> PayloadUnit;
"missile" -> TimedKillUnit;
"tank" -> TankUnit;
"hover" -> ElevationMoveUnit;
"tether" -> BuildingTetherPayloadUnit;
"crawl" -> CrawlUnit;*/
newUnit("初甲",MechUnit);
newUnit("次甲",MechUnit);
newUnit("重甲",MechUnit);
newUnit("超甲",MechUnit);
newUnit("终甲",MechUnit);
newUnit("天甲",MechUnit);

newUnit("爬行者",MechUnit);
newUnit("毒蜢",LegsUnit);
newUnit("毒狼",LegsUnit);
newUnit("血蝗",LegsUnit);
newUnit("冥界",LegsUnit);
newUnit("佛戮",LegsUnit);

newUnit("烛火",MechUnit);
newUnit("电流",MechUnit);
newUnit("脉冲",MechUnit);
newUnit("电离",MechUnit);
newUnit("电辉",LegsUnit);
newUnit("烨煜",LegsUnit);

newUnit("烈空",UnitEntity);
newUnit("垠天",UnitEntity);
newUnit("灼日",UnitEntity);
newUnit("宇空",UnitEntity);
newUnit("宙斯",UnitEntity);
newUnit("天元",UnitEntity);

newUnit("Lv1挖矿机",PayloadUnit);
newUnit("Lv2挖矿机",PayloadUnit);
newUnit("Lv3挖矿机",PayloadUnit);
newUnit("Lv4挖矿机",PayloadUnit);
newUnit("Lv5挖矿机",PayloadUnit);
newUnit("Lv6挖矿机",PayloadUnit);

newUnit("溪鲫",UnitWaterMove);
newUnit("河豚",UnitWaterMove);
newUnit("江鳄",UnitWaterMove);
newUnit("虎鲨",UnitWaterMove);
newUnit("雷章",UnitWaterMove);
newUnit("洋帝",UnitWaterMove);

newUnit("暗蚪",UnitWaterMove);
newUnit("潜虾",UnitWaterMove);
newUnit("刑鲸",UnitWaterMove);
newUnit("鹦鹉螺",UnitWaterMove);
newUnit("龙帝",UnitWaterMove);
newUnit("螣渊",UnitWaterMove);


//newUnit("暴风雪",MechUnit);


newUnit("Boss",UnitEntity);
newUnit("Boss(陆)",MechUnit);

newUnit("探索者",UnitEntity);
newUnit("探索者ll",UnitEntity);
newUnit("特斯拉",UnitEntity);
newUnit("特斯拉强化机",UnitEntity);
//探索者.coreUnitDock = true