//此代码来自无限宇宙
const lib = require("lib");
const {基础核心} = require('核心');
const 凌星 = new JavaAdapter(Planet, {
    load() {
        this.meshLoader = prov(() => new HexMesh(凌星, 7));
        this.super$load();
    }
}, "凌星", Planets.sun, 1);

const c1 = Color.valueOf("#005df9"), c2 = Color.valueOf("#005df9"), c3 = Color.valueOf("#005df9");
const sS = require("sectorSize");
sS.planetGrid(凌星, 3);

凌星.generator = extend(SerpuloPlanetGenerator,{
	getDefaultLoadout() {
		return Schematics.readBase64("bXNjaAF4nGNgYmBiYWDJS8xNZWB7tmDH0/3NDOzFJamJuZkpDFzFyRmpuYklmcnFDNwpqcXJRZkFJZn5eQwMDGw5iUmpOcUMTNGxjAySTyd0PJu57en2pU92zNJ9On/X84UNULMYGBgZIAAAnkkmsw==");
	},
	allowLanding (sector) {
		return false
	},
    getColor(position) {
        var depth = Simplex.noise3d(4, 4, 0.56, 1.7, position.x, position.y, position.z) / 2;
        return c1.write(c3).lerp(c2, Mathf.clamp(Mathf.round(depth, 0.25)));
    },
});

凌星.atmosphereColor = Color.valueOf("2d787d");
凌星.landCloudColor = Color.valueOf("2d787d");
凌星.atmosphereRadIn = 0.005;
凌星.atmosphereRadOut = 0.05;
凌星.lightSrcTo = 0.5;
凌星.lightDstFrom  = 0.2;
凌星.localizedName = "凌星";
凌星.visible = true;
凌星.bloom = false;
凌星.updateLighting = true;
凌星.accessible = true;
凌星.launchCapacityMultiplier = 0.6;
凌星.allowLaunchSchematics = true;//开启发射核心蓝图
凌星.description = " 这是一个富饶的星球，丰富的矿藏也招惹了一些敌人……攻下这里，发展科技，开启合晶之旅吧！";
凌星.allowSectorInvasion = false;//模拟攻击图入侵
凌星.allowWaveSimulation = true;//模拟后台波次
凌星.alwaysUnlocked = true;
凌星.clearSectorOnLose = false;
凌星.allowLaunchLoadout = true;
凌星.startSector = 0;
凌星.orbitRadius = 100;
凌星.tidalLock = false
凌星.iconColor = Color.valueOf("#00c7fc");
凌星.rotateTime = 300;
凌星.hiddenItems.addAll(Items.serpuloItems)
凌星.hiddenItems.addAll(Items.erekirItems)
凌星.defaultCore = 基础核心

exports.凌星= 凌星



const map1 = new SectorPreset("降临点", 凌星, 0);
map1.alwaysUnlocked = true;
map1.difficulty = 0;
map1.captureWave = 25;
map1.description = " ";
map1.localizedName = "降临点";
exports.map1 = map1;

const map3 = new SectorPreset("孢子裂谷", 凌星, 31);
map3.alwaysUnlocked = false;
map3.description = "站稳脚跟后，我们来到了这里，发现了一些碳单质，研究它们的使用。"
map3.difficulty = 2;
map3.captureWave = 30;
map3.localizedName = "孢子裂谷";
exports.map3 = map3;

const map4 = new SectorPreset("袭击", 凌星, 89);
map4.alwaysUnlocked = false;
map4.description = "敌人发现了我们，他们派出了大量兵力， 抵御敌人的进攻！"
map4.difficulty = 6;
map4.captureWave = 45;
map4.localizedName = "袭击";
exports.map4 = map4;

const map5 = new SectorPreset("前哨基地", 凌星, 101);
map5.alwaysUnlocked = false;
map5.description = "这里是敌人的一个前哨基地，有金属锡，占领这里，研究它的使用。"
map5.difficulty = 4;
map5.localizedName = "前哨基地";
exports.map5 = map5;

const map6 = new SectorPreset("废渣厂", 凌星, 110);
map6.alwaysUnlocked = false;
map6.description = "这里是敌人的一个废渣厂，有废渣，占领这里，研究它的使用。"
map6.difficulty = 6;
map6.captureWave = 50;
map6.localizedName = "废渣厂";
exports.map6 = map6;

const map7 = new SectorPreset("炮台研究所", 凌星, 1);
map7.alwaysUnlocked = false;
map7.description = "这里是敌人的一个炮台研究基地，攻下它。"
map7.difficulty = 6;
map7.localizedName = "炮台研究所";
exports.map7 = map7;

const map8 = new SectorPreset("培养区", 凌星, 68);
map8.alwaysUnlocked = false;
map8.description = "这里是敌人的培养区，攻下它。"
map8.difficulty = 4;
map8.captureWave = 30;
map8.localizedName = "培养区";
exports.map8 = map8;

const map9 = new SectorPreset("冰谷", 凌星, 5);
map9.alwaysUnlocked = false;
map9.description = "这里是敌人的陆辅基地，驻扎了一个陆辅中队。"
map9.difficulty = 6;
map9.captureWave = 45;
map9.localizedName = "冰谷";
exports.map9 = map9;

const map10 = new SectorPreset("粒子扩散炮", 凌星, 6);
map10.alwaysUnlocked = false;
map10.description = "这里有一台小型扩散轨道炮，占领这里，研究它。"
map10.difficulty = 8;
map10.captureWave = 70;
map10.localizedName = "粒子扩散炮";
exports.map10 = map10;

const map11 = new SectorPreset("狭窄基地", 凌星, 7);
map11.alwaysUnlocked = false;
map11.description = "这里是敌人的一个小基地，有许多小科技，占领这里，研究它们。"
map11.difficulty = 4;
map11.localizedName = "狭窄基地";
exports.map11 = map11;

const map12 = new SectorPreset("河滩", 凌星, 9);
map12.alwaysUnlocked = false;
map12.description = "这里有两台废弃的铝钢厂，研究它。"
map12.difficulty = 4;
map12.captureWave = 35;
map12.localizedName = "河滩";
exports.map12 = map12;

const map13 = new SectorPreset("洄流", 凌星, 10);
map13.alwaysUnlocked = false;
map13.description = " 河滩之外坐落着这一串群岛。 据记载这里曾有生产[accent]塑胶[]的建筑。\n\n抵御敌人的海军，在岛上建立基地，研究生产建筑。"
map13.difficulty = 6;
map13.captureWave = 50;
map13.localizedName = "洄流";
exports.map13 = map13;

const map14 = new SectorPreset("冰封火山口", 凌星, 19);
map14.alwaysUnlocked = false;
map14.description = " 解锁能量压缩机与金钢钻头"
map14.difficulty = 8;
map14.captureWave = 80;
map14.localizedName = "冰封火山口";
exports.map14 = map14;

const map15 = new SectorPreset("金林", 凌星, 33);
map15.alwaysUnlocked = false;
map15.description = "有金"
map15.difficulty = 6;
map15.captureWave = 70;
map15.localizedName = "金林";
exports.map15 = map15;

const map16 = new SectorPreset("石油带", 凌星, 99);
map16.alwaysUnlocked = false;
map16.description = "解锁初代合晶工厂"
map16.difficulty = 10;
map16.captureWave = 75;
map16.localizedName = "石油带";
exports.map16 = map16;

const map17 = new SectorPreset("极地冰原", 凌星, 48);
map17.alwaysUnlocked = false;
map17.description = ""
map17.difficulty = 10;
map17.captureWave = 80;
map17.localizedName = "极地冰原";
exports.map17 = map17;

const map18 = new SectorPreset("富能带", 凌星, 52);
map18.alwaysUnlocked = false;
map18.description = "解锁大型地热和地能发电机"
map18.difficulty = 10;
map18.captureWave = 45;
map18.localizedName = "富能带";
exports.map18 = map18;

const map19 = new SectorPreset("跌宕裂谷", 凌星, 58);
map19.alwaysUnlocked = false;
map19.description = "解锁凝能晶压缩机"
map19.difficulty = 11;
map19.captureWave = 18;
map19.localizedName = "跌宕裂谷";
exports.map19 = map19;

const map20 = new SectorPreset("海潮", 凌星, 41);
map20.alwaysUnlocked = false;
map20.description = ""
map20.difficulty = 8;
map20.captureWave = 40;
map20.localizedName = "海潮";
exports.map20 = map20;

const map21 = new SectorPreset("穿越ll型", 凌星, 79);
map21.alwaysUnlocked = false;
map21.description = ""
map21.difficulty = 8;
//map21.captureWave = 18;
map21.localizedName = "穿越ll型";
exports.map21 = map21;

const map22 = new SectorPreset("荒芜沙漠", 凌星, 4);
map22.alwaysUnlocked = false;
map22.description = ""
map22.difficulty = 10;
map22.captureWave = 50;
map22.localizedName = "荒芜沙漠";
exports.map22 = map22;

const map23 = new SectorPreset("暗流", 凌星, 8);
map23.alwaysUnlocked = false;
map23.description = ""
map23.difficulty = 11;
map23.captureWave = 55;
map23.localizedName = "暗流";
exports.map23 = map23;

const map24 = new SectorPreset("赤金矿脉", 凌星, 11);
map24.alwaysUnlocked = false;
map24.description = ""
map24.difficulty = 11;
map24.captureWave = 60;
map24.localizedName = "赤金矿脉";
exports.map24 = map24;

const map25 = new SectorPreset("冥域", 凌星, 32);
map25.alwaysUnlocked = false;
map25.description = ""
map25.difficulty = 11;
map25.captureWave = 60;
map25.localizedName = "冥域";
exports.map25 = map25;

const map26 = new SectorPreset("资源站点", 凌星, 36);
map26.alwaysUnlocked = false;
map26.description = ""
map26.difficulty = 11;
map26.captureWave = 15;
map26.localizedName = "资源站点";
exports.map26 = map26;

const map27 = new SectorPreset("幽暗", 凌星, 37);
map27.alwaysUnlocked = false;
map27.description = ""
map27.difficulty = 11;
map27.captureWave = 30;
map27.localizedName = "幽暗";
exports.map27 = map27;

const map28 = new SectorPreset("分冥", 凌星, 46);
map28.alwaysUnlocked = false;
map28.description = ""
map28.difficulty = 11;
map28.captureWave = 55;
map28.localizedName = "分冥";
exports.map28 = map28;

const map29 = new SectorPreset("涡旋煤坑", 凌星, 12);
map29.alwaysUnlocked = false;
map29.description = "我们在探索中意外掉入这裂谷，发现敌人的支援道路，守住此地，进军基地。"
map29.difficulty = 11;
map29.captureWave = 50;
map29.localizedName = "涡旋煤坑";
exports.map29 = map29;

const map30 = new SectorPreset("都江堰", 凌星, 13);
map30.alwaysUnlocked = false;
map30.description = "历史上的都江堰，被敌人占领了，攻下都江堰，投入使用"
map30.difficulty = 11;
//map30.captureWave = 50;
map30.localizedName = "都江堰";
exports.map30 = map30;

const map31 = new SectorPreset("红石洞口", 凌星, 14);
map31.alwaysUnlocked = false;
map31.description = "有很多怪"
map31.difficulty = 11;
map31.captureWave = 100;
map31.localizedName = "红石洞口";
exports.map31 = map31;

const map32 = new SectorPreset("黄金山谷", 凌星, 17);
map32.alwaysUnlocked = false;
map32.description = ""
map32.difficulty = 11;
map32.captureWave = 50;
map32.localizedName = "黄金山谷";
exports.map32 = map32;

const map33 = new SectorPreset("幽暗峡谷", 凌星, 21);
map33.alwaysUnlocked = false;
map33.description = ""
map33.difficulty = 11;
map33.captureWave = 75;
map33.localizedName = "幽暗峡谷";
exports.map33 = map33;


