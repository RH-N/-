const lib = require("lib");
const {基础核心} = require('核心');
const {初甲,次甲,重甲,烈空,垠天,灼日,超甲,电离,宇空,天甲,佛戮} = require('单位');
const {单管炮,突进,突围,集束,涓涓,重击,陨星,突进ll型,灾灭,天景} = require('炮/炮');
const {硅提纯机,硅粗制机,大型铝钢墙,涡轮泵,水力发电机} = require('工厂');
const {map1,map3,map4,map5,map6,map7,map8,map9,map10,map11,map12,map13,map14,map15,map16,map17,map18,map19,map20,map21,map22,map23,map24,map25,map26,map27,map28,map29,map30,map31,map32,map33} = require('星球');
const {赤金} = require('物品');


Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map1, {
        parent: '基础核心',
    });
}));



Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map3, {
        parent: '降临点',
        objectives: Seq.with(
            new Objectives.SectorComplete(map1),
              new Objectives.Research(单管炮),
        ),
    });
}));


Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map4, {
        parent: '降临点',
        objectives: Seq.with(
            new Objectives.SectorComplete(map3),
            new Objectives.Research(集束),
        ),
    });
}));


Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map5, {
        parent: '袭击',
        objectives: Seq.with(
            new Objectives.SectorComplete(map4),
            new Objectives.Research(次甲),
            new Objectives.Research(垠天),
        ),
    });
}));
exports.map5 = map5;

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map6, {
        parent: '袭击',
        objectives: Seq.with(
            new Objectives.SectorComplete(map5),
            new Objectives.SectorComplete(map4),
            new Objectives.Research(突进),
            new Objectives.Research(突围),
        ),
    });
}));


Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map7, {
        parent: '前哨基地',
        objectives: Seq.with(
            new Objectives.SectorComplete(map6),
            new Objectives.Research(重甲),
            new Objectives.Research(灼日),
            
        ),
    });
}));


Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map8, {
        parent: '孢子裂谷',
        objectives: Seq.with(
            new Objectives.SectorComplete(map3),
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map9, {
        parent: '袭击',
        objectives: Seq.with(
            new Objectives.SectorComplete(map4),
     new Objectives.Research(大型铝钢墙),       
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map10, {
        parent: '冰谷',
        objectives: Seq.with(
            new Objectives.SectorComplete(map6),    
             new Objectives.SectorComplete(map9),    
             new Objectives.Research(重击) 
             // new Objectives.Research(陨星)
        ),
    });
}));


Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map11, {
        parent: '前哨基地',
        objectives: Seq.with(
            new Objectives.SectorComplete(map5),     
             // new Objectives.Research(陨星)
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map12, {
        parent: '前哨基地',
        objectives: Seq.with(
            new Objectives.SectorComplete(map5),     
             new Objectives.Research(涡轮泵)
             // new Objectives.Research(水力发电机)      
        ),
    });
}));


Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map13, {
        parent: '河滩',
        objectives: Seq.with(
            new Objectives.SectorComplete(map12),     
             new Objectives.Research(突进ll型)
              // new Objectives.Research(陨星)      
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map14, {
        parent: '洄流',
        objectives: Seq.with(
            new Objectives.SectorComplete(map10),     new Objectives.SectorComplete(map13),  
          //   new Objectives.Research(突进ll型)
              // new Objectives.Research(陨星)      
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map15, {
        parent: '培养区',
        objectives: Seq.with(
            new Objectives.SectorComplete(map8),     
               new Objectives.SectorComplete(map12),     
             // new Objectives.Research(陨星)
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map16, {
        parent: '金林',
        objectives: Seq.with(
            new Objectives.SectorComplete(map14),     
               //new Objectives.SectorComplete(map12),     
             // new Objectives.Research(陨星)
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map17, {
        parent: '石油带',
        objectives: Seq.with(
            new Objectives.SectorComplete(map16),     
               //new Objectives.SectorComplete(map12),     
             // new Objectives.Research(陨星)
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map18, {
        parent: '石油带',
        objectives: Seq.with(
            new Objectives.SectorComplete(map17),     
               //new Objectives.SectorComplete(map12),     
             // new Objectives.Research(陨星)
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map19, {
        parent: '富能带',
        objectives: Seq.with(
            new Objectives.SectorComplete(map18),     
               //new Objectives.SectorComplete(map12),     
             // new Objectives.Research(陨星)
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map20, {
        parent: '洄流',
        objectives: Seq.with(
            new Objectives.SectorComplete(map18),     
               //new Objectives.SectorComplete(map12),     
             // new Objectives.Research(陨星)
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map21, {
        parent: '炮台研究所',
        objectives: Seq.with(
            new Objectives.SectorComplete(map17),     
               //new Objectives.SectorComplete(map12),     
              new Objectives.Research(超甲),
              new Objectives.Research(电离),
             new Objectives.Research(宇空) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map22, {
        parent: '金林',
        objectives: Seq.with(
            new Objectives.SectorComplete(map17),     
            new Objectives.SectorComplete(map10),     
               //new Objectives.SectorComplete(map12),      
          new Objectives.Research(灾灭) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map23, {
        parent: '海潮',
        objectives: Seq.with(
            new Objectives.SectorComplete(map20),     
          //  new Objectives.SectorComplete(map10),     
               //new Objectives.SectorComplete(map12),      
         new Objectives.Research(天景) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map24, {
        parent: '跌宕裂谷',
        objectives: Seq.with(
            new Objectives.SectorComplete(map23),     
          //  new Objectives.SectorComplete(map10),     
               //new Objectives.SectorComplete(map12),      
        // new Objectives.Research(天景) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map25, {
        parent: '暗流',
        objectives: Seq.with(
            new Objectives.SectorComplete(map23),     
          //  new Objectives.SectorComplete(map10),     
               //new Objectives.SectorComplete(map12),      
        // new Objectives.Research(天景) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map26, {
        parent: '暗流',
        objectives: Seq.with(
            new Objectives.SectorComplete(map25),     
          new Objectives.SectorComplete(map24),     
               new Objectives.SectorComplete(map20),      
        // new Objectives.Research(天景) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map27, {
        parent: '资源站点',
        objectives: Seq.with(
            new Objectives.SectorComplete(map26),     
        //  new Objectives.SectorComplete(map24),     
              // new Objectives.SectorComplete(map20),      
        // new Objectives.Research(天景) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map28, {
        parent: '冥域',
        objectives: Seq.with(
            new Objectives.SectorComplete(map25),     
          new Objectives.SectorComplete(map26),     
              // new Objectives.SectorComplete(map20),      
        // new Objectives.Research(天景) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map29, {
        parent: '分冥',
        objectives: Seq.with(
            new Objectives.SectorComplete(map28),     
          //new Objectives.SectorComplete(map26),     
              // new Objectives.SectorComplete(map20),      
        // new Objectives.Research(天景) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map30, {
        parent: '狭窄基地',
        objectives: Seq.with(
            new Objectives.SectorComplete(map21),     
          new Objectives.SectorComplete(map26),     
              // new Objectives.SectorComplete(map20),      
         new Objectives.Research(天甲) ,
         new Objectives.Research(佛戮) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map31, {
        parent: '赤金矿脉',
        objectives: Seq.with(
            new Objectives.SectorComplete(map28),     
          new Objectives.SectorComplete(map29),     
              // new Objectives.SectorComplete(map20),      
       //  new Objectives.Research(天甲) ,
         //new Objectives.Research(2级合晶墙) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map32, {
        parent: '金林',
        objectives: Seq.with(
            new Objectives.SectorComplete(map15),     
          new Objectives.SectorComplete(map24),     
              // new Objectives.SectorComplete(map20),      
         new Objectives.Research(赤金) ,
         //new Objectives.Research(2级合晶墙) ,
        ),
    });
}));

Events.on(ContentInitEvent, cons(e => {
    lib.addToResearch(map33, {
        parent: '跌宕裂谷',
        objectives: Seq.with(
            new Objectives.SectorComplete(map19),     
          new Objectives.SectorComplete(map32),     
              // new Objectives.SectorComplete(map20),      
        // new Objectives.Research(赤金) ,
         //new Objectives.Research(2级合晶墙) ,
        ),
    });
}));