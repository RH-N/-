const library = require("library");
const myitems = require("物品");
const 次世代合晶工厂 = library.MultiCrafter(GenericCrafter, GenericCrafter.GenericCrafterBuild, "次世代合晶工厂", [
  {
    input: {
      items: ["合晶工业-金辉合金/6","合晶工业-铀/8"],     
      liquids: ["合晶工业-能量流体/12"],
     power: 18,
    },
    output: {
      items: ["合晶工业-初代合晶/5"],
    },
    craftTime: 120,
  }, 
  {
    input: {
      items: ["合晶工业-初代合晶/10","合晶工业-赤金/12","合晶工业-固态能/15","合晶工业-金辉合金/15"],     
      liquids: ["合晶工业-能量流体/12"],
      power: 28,
    },
    output: {
      items: ["合晶工业-次代合晶/3"],
    },
    craftTime: 150,
  },  
    {
    input: {
      items: ["合晶工业-初代合晶/50","合晶工业-次代合晶/20","合晶工业-凝能晶/25","合晶工业-金辉合金/60"],     
      liquids: ["合晶工业-浓缩能量流体/10"],
      power: 40,
    },
    output: {
      items: ["合晶工业-次代合晶/3"],
    },
    craftTime: 250,
  },  
])
次世代合晶工厂.update = true
次世代合晶工厂.category = Category.crafting;
次世代合晶工厂.buildVisibility = BuildVisibility.shown;
